<?php
$min = 1; 
$max = 50;
$guess = 4; //Change this value to test!
$num = 16; // Change this value to test!

// If you really want to go nuts, try this:
//$num = rand($min, $max);