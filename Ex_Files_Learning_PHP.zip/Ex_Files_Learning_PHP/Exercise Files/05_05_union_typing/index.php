<?php

function double(int|float|null $a ) {
    return $a * 2;
}

echo double(true);