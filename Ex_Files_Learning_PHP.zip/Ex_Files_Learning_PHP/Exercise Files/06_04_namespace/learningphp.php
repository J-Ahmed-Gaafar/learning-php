<?php

namespace learningPHP;

function double( $a ) {
    return $a * 2;
}