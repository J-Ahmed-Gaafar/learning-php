<html>
  <head><title>Hello World Script</title></head>
  <body>
    <p><?php echo 'Hello World'; ?></p>
  </body>
</html>
