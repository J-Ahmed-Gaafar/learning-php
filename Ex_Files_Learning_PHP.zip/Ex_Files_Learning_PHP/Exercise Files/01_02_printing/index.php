<?php
    // Single Line comment: Hello World! 
    echo 'Hello World'; 
?>

<?='Hello World'?>

<?php
/* We prefer to use echo. 
    print is a little slower.
*/
    print 'Hello World'; 
?>