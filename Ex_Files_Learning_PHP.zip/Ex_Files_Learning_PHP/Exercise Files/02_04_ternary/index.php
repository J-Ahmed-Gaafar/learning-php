<?php
$is_logged_in = true;
$name = null;
//echo "Welcome" . ($is_logged_in ? " back!" : "!");

$name = $name ?: 'Joe';


echo $name;
