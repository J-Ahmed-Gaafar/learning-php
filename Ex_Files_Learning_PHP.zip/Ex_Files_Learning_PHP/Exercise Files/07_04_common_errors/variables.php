<?php
$name = "Joe";