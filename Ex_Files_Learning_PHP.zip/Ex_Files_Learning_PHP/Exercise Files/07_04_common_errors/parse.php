<?php
$a = 45
 
echo hello; 

$b = array( 'red' => 'Stop',
		'yellow' => Slow',
		'green' => 'Go',
);

if ( empty( $a ) { 
    echo '$a is empty.';
}