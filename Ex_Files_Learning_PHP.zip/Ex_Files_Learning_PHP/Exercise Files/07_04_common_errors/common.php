<?php
include 'variables.php';

//header( 'Location: index.php' ); 

$colors = array( 'red', 'blue', 'green' );
echo $colors[3];