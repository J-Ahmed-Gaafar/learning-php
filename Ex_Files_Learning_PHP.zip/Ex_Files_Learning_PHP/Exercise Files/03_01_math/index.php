<?php

echo 5 * 6 + 3 - 1 . '<br/>';
echo 3 + 5 * 6 - 1 . '<br/>';

echo 5**2 . '<br/>';

echo 5**2 * 6 + 3 - 1 . '<br/>';