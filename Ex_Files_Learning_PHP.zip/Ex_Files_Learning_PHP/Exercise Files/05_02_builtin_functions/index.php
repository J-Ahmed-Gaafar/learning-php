<?php
echo date( 'F d, Y' );