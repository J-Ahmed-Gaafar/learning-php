<?php
    echo "Joe's Nickname in HS was \"Joey Calzone\"";