<?php 
$title = 'Learning PHP Template';
$description = 'Server Side Includes are cool!';
$author = 'Joe Casabona';