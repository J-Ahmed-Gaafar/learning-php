<?php
$i = 10;

do {
    echo "<p>$i</p>";
    $i++;
} while ( $i < 10 );

while( $i < 10 ) {
    echo "<p>$i</p>";
    $i++;
}