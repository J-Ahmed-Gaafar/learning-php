<?php require_once 'inc/header.php'; ?>
		<?php if ( isset( $_COOKIE['visited'] ) ): ?>
			<h3>Welcome back!</he>
		<?php endif; ?>
     <p>Hello world! This is my PHP website!</p>
<?php require_once 'inc/footer.php'; ?>
