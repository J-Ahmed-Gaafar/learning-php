<?php include 'templates/header.php'; ?>
<!--Main Content Start-->
            <h2>Welcome!</h2>
            <p>Hello world! This is my PHP website!</p>
<!--End Main Content-->
<?php include 'templates/footer.php'; ?>