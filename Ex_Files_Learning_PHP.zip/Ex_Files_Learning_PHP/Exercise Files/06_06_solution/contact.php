<?php include 'templates/header.php'; ?>
<!--Main Content Start-->
            <h2>Contact <?php echo $author; ?></h2>
            <p>Email me joe [at] casabona.org</p>
<!--End Main Content-->
<?php include 'templates/footer.php'; ?>