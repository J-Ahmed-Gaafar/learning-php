<?php include 'templates/header.php'; ?>
<!--Main Content Start-->
            <h2>About <?php echo $author; ?></h2>
            <p>Biographical Text!</p>
<!--End Main Content-->
<?php include 'templates/footer.php'; ?>