<?php
$title = 'Learning PHP Template Challenge';
$description = 'Description goes here.';
$author = 'Joe Casabona';